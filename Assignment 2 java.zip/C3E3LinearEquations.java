/*3.3 (Algebra: solve 2 * 2 linear equations) A linear equation can be solved using
Cramer�s rule given in Programming Exercise 1.13. Write a program that prompts
the user to enter a, b, c, d, e, and f and displays the result. If ad - bc is 0, report
that �The equation has no solution.�
*/

import java.util.Scanner;

public class C3E3LinearEquations {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
// Solving a linear equation 
		System.out.println("Enter the values of a,b,c,d,e,f(in a single line separated by space) : ");

		double a = input.nextDouble();
		double b = input.nextDouble();
		double c = input.nextDouble();
		double d = input.nextDouble();
		double e = input.nextDouble();
		double f = input.nextDouble();
// Using Cramer's rule to find the value of x and y 		

		double x = (e * d - b * f) / (a * d - b * c);
		double y = (a * f - e * c) / (a * d - b * c);

		if (a * d - b * c == 0) {
			System.out.println("The equation has no solution");
		} else {
			System.out.println("The valus of x is : " + x);
			System.out.println("The value of y is : " + y);
		}
	}
}
