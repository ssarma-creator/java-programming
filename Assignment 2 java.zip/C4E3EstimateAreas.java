
/*4.3 (Geography: estimate areas) Use the GPS locations for Atlanta, Georgia;
Orlando, Florida; Savannah, Georgia; and Charlotte, North Carolina in the figure in Section 4.1 to compute the estimated area enclosed by these four cities.
(Hint: Use the formula in Programming Exercise 4.2 to compute the distance
between two cities. Divide the polygon into two triangles and use the formula in
Programming Exercise 2.19 to compute the area of a triangle.)
*/
import java.util.Scanner;

public class C4E3EstimateAreas {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		// The latitude and longitude of the four places Charlotte, Atlanta, Orlando and
		// Savannah :

		double x1 = 35.2270869;
		double y1 = -80.8431267;
		System.out.println("The latitude and longitude of Charlotte is " + x1 + " and " + y1);

		double x2 = 33.7489954;
		double y2 = -84.3879824;
		System.out.println("The latitude and longitude of Atlanta is " + x2 + " and " + y2);

		double x3 = 28.5383355;
		double y3 = -81.3792365;
		System.out.println("The latitude and longitude of Orlando is " + x3 + " and " + y3);

		double x4 = 32.0835407;
		double y4 = -81.0998342;
		System.out.println("The latitude and longitude of Savannah is " + x4 + " and " + y4);
		
		//Converting degree to radian
		x1 = Math.toRadians(x1);
		y1 = Math.toRadians(y1);
		x2 = Math.toRadians(x2);
		y2 = Math.toRadians(y2);
		x3 = Math.toRadians(x3);
		y3 = Math.toRadians(y3);
		x4 = Math.toRadians(x4);
		y4 = Math.toRadians(y4);
		
		// 6371.01 is the average radius of the earth
		// Distance between Charlotte and Atlanta
		double d1 = 6371.01 * Math.acos(Math.sin(x1) * Math.sin(x2) + Math.cos(x1) * Math.cos(x2) * Math.cos(y1 - y2));
		System.out.println("The distance between Charlotte and Atlanta is " + d1);

		// Distance between Atlanta and Orlando
		double d2 = 6371.01 * Math.acos(Math.sin(x2) * Math.sin(x3) + Math.cos(x2) * Math.cos(x3) * Math.cos(y2 - y3));
		System.out.println("The distance between Atlanta and Orlando is " + d2);

		// Distance between Orlando and Savannah
		double d3 = 6371.01 * Math.acos(Math.sin(x3) * Math.sin(x4) + Math.cos(x3) * Math.cos(x4) * Math.cos(y3 - y4));
		System.out.println("The distance between Orlando and Savannah is " + d3);

		// Distance between Savannah and Charlotte
		double d4 = 6371.01 * Math.acos(Math.sin(x4) * Math.sin(x1) + Math.cos(x4) * Math.cos(x1) * Math.cos(y4 - y1));
		System.out.println("The distance between Savannah and Charlotte is " + d4);

		// Distance between Charlotte and Orlando
		double d5 = 6371.01 * Math.acos(Math.sin(x1) * Math.sin(x3) + Math.cos(x1) * Math.cos(x3) * Math.cos(y1 - y3));
		System.out.println("The distance between Charlotte and Orlando is " + d5);

		// s1 is for triangle containing Charlotte, Atlanta and Orlando
		double s1 = (d1 + d2 + d5) / 2;

		// s2 is for triangle containing Charlotte,Orlando and Savannah
		double s2 = (d3 + d4 + d5) / 2;

		// A1 is area for triangle Charlotte, Atlanta and Orlando
		double A1 = Math.sqrt(s1 * (s1 - d1) * (s1 - d2) * (s1 - d5));
		System.out.println("Area of the triangle containing Charlotte, Atlanta and Orlando " + A1);

		// A2 is area for triangle Charlotte,Orlando and Savannah
		double A2 = Math.sqrt(s2 * (s2 - d5) * (s2 - d4) * (s2 - d3));
		System.out.println("Area of the triangle containing Charlotte, Orlando and Savannah " + A2);
		// Total area of the of the polygon
		double Area = A1 + A2;

		System.out.println("Total area of the polygon : " + Area);
	}
}
