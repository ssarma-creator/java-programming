
/*Questions - 5.16,5.20 and 6.10
	In this program we find the factors of a number
	  find whether the input number is prime or not 
	  and display the first 50 prime numbers*/

import java.util.Scanner;
import java.util.Arrays;

public class C5E16PrimeNumbersAndFactors {

	final static int Number_in_a_line = 8;
	public static int[] primeNumberArray = new int[170];

	public static void main(String[] args) {

		int inputNumber;
		int repeatProgram = 1;

		Scanner input = new Scanner(System.in);

		// stores prime number between 2 and 1000 and displays first 50
		storePrimeNumber(2, 1000);
		while (repeatProgram == 1) {

			System.out.println("\nFollowing are the prime number between 2 and 50 inclusive :");
			displayPrimeNumbers(2, 50);
			// Finding whether the input number is prime or not
			int repeatInput = 1;
			while (repeatInput == 1) {
				System.out.println("\nEnter a number to find its prime or not(number should be less than 10000) :");
				inputNumber = input.nextInt();

				if (inputNumber < 0 || inputNumber > 1000)
					System.out.println("This is invalid input. Please put a valid number between 0-10000");
				// Checking for a number whether its prime or not and then display the factors
				// of the number
				else {
					if (findPrime(inputNumber)) {
						System.out.println("The number " + inputNumber + " is a Prime Number");
					} else
						System.out.println("The number " + inputNumber + " is not a Prime Number");
					System.out.println("Smallest factors of " + inputNumber + " : " + factorsOfNumber(inputNumber));

				}

				System.out
						.println("\nWould you check for another number and continue (enter 1 for yes, 0 to exit) ? :");

				repeatInput = input.nextInt();
			}
			System.out.println("\n Program continue (enter 1 for yes, 0 to exit)? :");
			repeatProgram = input.nextInt();
		}

	}

	private static void displayPrimeNumbers(int i, int j) {

	}

	// This method stores prime number between 2 and 1000
	public static void storePrimeNumber(int startIndex, int endIndex) {

		int i = startIndex, j = 0;

		while (i <= endIndex) {
			if (isPrime(i)) {
				primeNumberArray[j++] = i;
			}
			i++;
		}
	}

	public static String factorsOfNumber(int number) {
		String result = "";
		int i = 2;

		if (number < 0) {
			System.out.println("This is invalid input.Please enter valid positive number");
		}
		// if input number is 0 or 2 it returns the number itself as it has no lowest
		// factor
		if (number >= 0 && number <= 2) {
			return result = result + number;
		}

		while (i <= number) {
			// it checks if divisor is prime and divisible by number
			if (isPrime(i) && number % i == 0) {
				result = result + i + " ";
				number = number / i;
			} else {
				i++;
			}
		}
		return result;
	}

	public static void displayNumber(int startNumber, int endNumber) {
		int i = startNumber;
		int maxNumberPerLine = 0;

		while (i <= endNumber) {
			// calls isPrime method to check if input number is prime or not
			if (isPrime(i)) {
				System.out.println(i + " ");
				maxNumberPerLine++;
			}
			if (maxNumberPerLine == Number_in_a_line) {
				maxNumberPerLine = 0;
				System.out.println();
			}
			i++;
		}
	}

	// this method checks whether the input number is prime or not and returns the
	// result
	public static boolean isPrime(int number) {
		int k = 2;

		if (number < 0) {
			System.out.println("This is invalid number. Please enter valid number");
			return false;
		}
		while (k <= number / 2) {
			if (number % k == 0 && number > 1) {
				return false;
			}
			k++;
		}
		return true;
	}

	// this method will check whether the input number is prime or not by checking
	// in the prime number array
	public static boolean findPrime(int number) {
		for (int i = 0; i < primeNumberArray.length; i++) {
			if (primeNumberArray[i] == number) {
				return true;
			}
		}

		return false;
	}
}
