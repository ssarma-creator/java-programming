
/*Questions -7.9,7.10,7.20
This program is finding the smallest element in a array 
finding the index of the smallest element 
and for revised selection sorting
*/
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class C7E9SortingAndSmallestNumber {
	final static int Array_size = 10;

	public static void main(String[] args) {
		double[] doubleArray = new double[Array_size];
		double number;

		int repeatProgram = 1;

		Scanner input = new Scanner(System.in);

		while (repeatProgram == 1) {
			// Finding the smallest number
			readInputArray(doubleArray);
			number = min(doubleArray);
			System.out.println("The smallest number is " + number);
			// Finding the index of the smallest number
			System.out.println("The index of smallest number is: " + indexOfSmallestNumber(doubleArray, number));
			// Sorting array
			System.out.println("The sorted array is : " + Arrays.toString(sortArray(doubleArray)));

			System.out.println("\nProgram continue (enter 1 for yes, 0 to exit)? : ");

			repeatProgram = input.nextInt();
		}
	}

	// this method accepts double array and it reads the input from the user
	public static void readInputArray(double[] array) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter ten numbers (separated by one space): ");
		for (int i = 0; i < 10; i++) {
			array[i] = input.nextDouble();
		}
	}

	// this method finds the smallest number in the double array
	public static double min(double[] array) {
		double minNumber = array[0];

		for (int i = 0; i < array.length; i++) {
			if (array[i] < minNumber)
				minNumber = array[i];
		}
		return minNumber;
	}

	// this method finds the index of the smallest number
	public static int indexOfSmallestNumber(double[] array, double smallestNumber) {
		for (int i = 0; i < array.length; i++) {
			if (smallestNumber == array[i])
				return i;
		}
		return -1;
	}

	// this method is used to sort using selection sort
	public static double[] sortArray(double[] array) {
		for (int i = array.length - 1; i >= 0; i--) {
			for (int j = i; j >= 0; j--) {
				if (array[j] > array[i]) {
					double temp = array[j];
					array[j] = array[i];
					array[i] = temp;
				}
			}
		}
		return array;
	}
}
