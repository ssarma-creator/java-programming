/*Exercise 9.1 - this program is used to calculate the area and perimeter of the rectangle*/

import java.util.InputMismatchException;

class C9E1Rectangle {

    private double height;
    private double width;
//default constructor which initialize height and width of rectangle to 1.0 value
    C9E1Rectangle() {
        setHeight(1.0);
        setWidth(1.0);
    }


    void C9E1RectangleClass(double height, double width) throws InputMismatchException {
        setHeight(height);
        setWidth(width);
    }

    C9E1Rectangle(double height, double width) throws InputMismatchException {
        this();
        setHeight(height);
        setWidth(width);
    }
    //method to set value of height
    public void setHeight(double height) throws InputMismatchException {
        this.height = getValidValue(height);
    }
//method to set value of width
    public void setWidth(double width) throws InputMismatchException {
        this.width = getValidValue(width);
    }
// this method returns height value
    public double getHeight() {
        return height;
    }
//this method returns width value
    public double getWidth() {
        return width;
    }
//this method calculates area of the rectangle
    public double getArea() {
        return height * width;
    }
//this method calculates perimeter of the rectangle
    public double getPerimeter() {
        return (2 * (height + width));

    }
//this method handles exception and returns valid value
    public double getValidValue(double value) {
        if (isValid(value)) {
            return value;

        }
        throw new InputMismatchException("0 or negative value is not allowed for height and width of rectangle");
    }
//it performs validation of the given value
    public boolean isValid(double value) {
        if (value > 0 && value <= Double.MAX_VALUE)
            return true;
        return false;


    }
}


