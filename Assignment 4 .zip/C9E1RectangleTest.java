

import java.util.Scanner;

public class C9E1RectangleTest {

    public static void main(String[] args) {

        int loopProgram = 1;
        Scanner input = new Scanner(System.in);
        boolean flag = false;

        C9E1Rectangle rec1 = new C9E1Rectangle();
        System.out.println("Default value of height and width (Separated by a space) : " + rec1.getHeight() + " " + rec1.getWidth());
        System.out.println("Default area of rectangle : " + rec1.getArea());
        System.out.println("Default perimeter of rectangle : " + rec1.getPerimeter());

        try {
            while (loopProgram == 1) {
                while (!flag) {
                    try {
                        System.out.println("\n Enter Rectangle height and width (separated by space): ");
                        double height = input.nextDouble();
                        double width = input.nextDouble();

                        C9E1Rectangle rec2 = new C9E1Rectangle(height, width);
                        System.out.println("Default area of the rectangle : " + rec2.getArea());
                        System.out.println("Default perimeter of the rectangle : " + rec2.getPerimeter());
                        flag = true;

                    } catch (Exception ex) {
                        input.nextLine();
                        System.out.println("Entered an invalid input : 0, string or negative value not allowed for height and width of rectangle");
                    }
                }
                System.out.println("Do you want to continue the program (enter 1 for yes or 0 to exit)? ");
                loopProgram = input.nextInt();
                flag = false;
            }
        } catch (Exception ex) {
            input.nextLine();
            System.out.println("Entered an invalid input : " + ex.getMessage());
        }

    }

}