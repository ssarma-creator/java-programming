/*excercise 9.5 - this program is used to display date in the format year/month/day format 
*/

import java.util.GregorianCalendar;

class DateFormat {
    private GregorianCalendar date;
// default constructor to initialize date
    DateFormat() {
        date = new GregorianCalendar();
    }
//this method uses day_of_month function
    public int getDay() {
        return date.get(GregorianCalendar.DAY_OF_MONTH);
    }
//this method uses month function 
    public int getMonth() {
        return date.get(GregorianCalendar.MONTH) + 1;

    }
//this method uses year function
    public int getYear() {
        return date.get(GregorianCalendar.YEAR);
    }
//this method uses setTimeInMillis function to calculate elapsed time
    public void setTimeInMillis(long millis) {
        date.setTimeInMillis(millis);
    }
//this method displays date in string format
    public String toString() {
        return getYear() + "/" + getMonth() + "/" + getDay();
    }

}

public class C9E5GregorianCalendar {
    public static void main(String[] args) {
        DateFormat d1 = new DateFormat();
        System.out.println("The current date is (yyyy/mm/dd):" + d1.toString());

        d1.setTimeInMillis(1234567898765L);
        System.out.println(
                "The elapsed date since Jan 1, 1970 for 1234567898765 millis is (yyyy-mm-dd): " + d1.toString());

    }
}
