
/*This program counts the number of characters, words, and lines in a text file 
  
*/
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.*;

public class C12E13CountProgram {
	public static void main(String[] args) {
		// this program JFileChooser to open a text file
		JFileChooser chooser = new JFileChooser();

		// Creates JfileChooser
		// It allows to select text file from the main directory
		FileNameExtensionFilter filter = new FileNameExtensionFilter("Text file", "txt");
		chooser.setFileFilter(filter);
		Frame nam = new Frame();

		int confirmControl = JOptionPane.YES_OPTION;

		while (confirmControl == JOptionPane.YES_OPTION) {

			// It opens a file dialog
			int returnVal = chooser.showOpenDialog(nam);

			// checks if user has selected a file

			if (returnVal == JFileChooser.APPROVE_OPTION) {

				File selectedFile = chooser.getSelectedFile();
				try {
					performfileOperations(selectedFile);
					confirmControl = JOptionPane.NO_OPTION;
				} catch (FileNotFoundException ex) {
					String outputRes = "\n File not found " + ex.getMessage()
							+ "\n Do you want to select another file?";
					confirmControl = JOptionPane.showConfirmDialog(nam, outputRes);
				} catch (IOException ex) {
					String outputRes = "\n I/O exception occurred." + ex.getMessage()
							+ "\n Do you want to select another file?";
					confirmControl = JOptionPane.showConfirmDialog(nam, outputRes);
				}
			} else {
				System.out.println("You chose to close this file: ");
				String outputRes = "Do you want to select another file?";
				confirmControl = JOptionPane.showConfirmDialog(nam, outputRes);
			}
		}
	}

	// it counts the characters, words and lines in the text file

	public static void performfileOperations(File filename) throws IOException, FileNotFoundException {

		FileReader fileName = new FileReader(filename);
		System.out.println("You chose to open this file: " + filename.getName());

		int i;
		int numCharacters = 0;
		int numLines = 0;
		int numWords = 0;
		while ((i = fileName.read()) != -1) {
			char a = (char) i;
			if (a == '\n') {
				numLines++;
			}
			if (Character.isWhitespace(a)) {
				numWords++;
			}
			numCharacters++;
		}

		System.out.println("\n Number of characters in this file: " + (numCharacters - numLines));
		System.out.println("\n Number of words in this file: " + (numWords + 1));
		System.out.println("\n Number of lines in this file: " + (numLines + 1));
	}
}
