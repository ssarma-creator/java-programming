
/*This program prompts the user to enter a password in JOption pane 
 * and checks the validation of the password
 */
import javax.swing.JOptionPane;

public class C6E18CheckPassword {

	final static int PASSWORD_LENGTH = 9;

	public static void main(String[] args) {

		// It creates JOptionPane and provides text field to enter password

		int option = JOptionPane.YES_OPTION;
		String message = "";

		while (option == JOptionPane.YES_OPTION) {
			try {

				/*
				 * Minimum length of the password is 9 and atleast two digits Letters can be
				 * upper case or lower case Special characters or whitespace not allowed
				 */
				String password = JOptionPane.showInputDialog("Enter a Password: \n"
						+ " 1. Must contain 9 or more letters \n" + " 2. Letters can be upper case or lower case \n "
						+ " 3. It must contain atleast two digits");

				if (isValidPassword(password)) {
					message = "Valid Password";
				} else {
					message = "Invalid Password. Try again.";
				}
				// Allows user to re-enter password
				option = JOptionPane.showConfirmDialog(null, message + "\n Do you want to continue?");
			} catch (Exception ex) {
				String outputRes = "Invalid Password : " + ex.getMessage() + "\n Do you want to continue?";
				option = JOptionPane.showConfirmDialog(null, outputRes);
			}
		}

	}

	/*
	 * This method checks password validation Password must have: Must contain 9
	 * digits or more letters Letters can be upper case or lower case It must
	 * contain atleast two digits
	 * 
	 */
	private static boolean isValidPassword(String password) throws Exception {
		if (password.length() < PASSWORD_LENGTH)
			return false;

		int numberCount = 0;

		for (char c : password.toCharArray()) {
			if (Character.isDigit(c)) {
				numberCount++;
			} else if (!Character.isLetter(c)) {
				return false;
			}
		}

		if (numberCount < 2)
			return false;

		return true;
	}
}