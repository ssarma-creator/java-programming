
/*This program prompts the user to enter a string followed by a character
 * Displays the number of the occurrences of the character in the string
*/
import java.util.InputMismatchException;
import java.util.Scanner;

public class C6E23CountOccurrences {

	private String stringEntered;

	// Default Constructor

	C6E23CountOccurrences() {
	}

	/*
	 * This constructor accepts string and check its validation
	 * 
	 * @param inputString accepts
	 */
	C6E23CountOccurrences(String inputString) {
		setInputString(inputString);
	}

	/*
	 * This method checks the validation of the input string
	 * 
	 */
	public void setInputString(String str) {
		Scanner input = new Scanner(System.in);

		while (true) {
			try {
				if (isValidString(str)) {
					this.stringEntered = str;
					return;
				} else {
					System.out.println("Enter String (should be consist of letters and whitespaces only) :");
					str = input.nextLine();
				}
			} catch (InputMismatchException ex) {
				input.nextLine();
				System.out.println("Invalid string format :" + ex.getMessage());
			}
		}

	}

	public String getInputString() {
		return stringEntered;
	}

	/*
	 * This checks whether the entered string is valid or not
	 * 
	 */
	public boolean isValidString(String str) throws InputMismatchException {
		if (str.length() == 0)
			return false;

		for (char c : str.toCharArray()) {
			if (Character.isLetter(c) || Character.isWhitespace(c)) {
			} else
				return false;
		}
		return true;
	}
	/*
	 * This method is used to count the occurrence of the given character in the
	 * input string
	 * 
	 */

	public int occurrenceOfChar(char character) {
		int count = 0;

		for (char c : stringEntered.toCharArray()) {
			if (c == character) {
				count++;
			}
		}
		return count;
	}

}
