
/*This program performs the testing for the string and count the occurrence
 * of the given character in the string
 */

import java.util.InputMismatchException;
import java.util.Scanner;

public class C6E23CountOccurrencesTest {
	public static void main(String args[]) {

		int loopOuterProgram = 1;
		int loopInnerProgram = 1;

		C6E23CountOccurrences stringObject;
		String input;
		Character charEntered;
//Exception handling to continue the loop program 
		
		try {

			while (loopOuterProgram == 1) {
				Scanner sc = new Scanner(System.in);

				System.out.println(
						"Enter a string and the character whose occurence you want to find (character in the next line): ");
				input = sc.nextLine();
				charEntered = sc.next().charAt(0);
				stringObject = new C6E23CountOccurrences(input);

				System.out.println("Number of occurence of " + charEntered + " in " + stringObject.getInputString() + " is : "
						+ stringObject.occurrenceOfChar(charEntered));

				while (loopInnerProgram == 1) {
					if (charEntered == null) {
						System.out.println("Enter character whose occurence you want to find in " + input + " : ");
						charEntered = sc.next().charAt(0);
						System.out.println("Occurrence of " + charEntered + " in " + stringObject.getInputString()
								+ " is : " + stringObject.occurrenceOfChar(charEntered));
					}

					charEntered = null;
					System.out.println("Want to find occurrence of character (enter 1 for yes, 0 to exit)? : ");
					loopInnerProgram = sc.nextInt();

				}

				input = null;
				System.out.println("Want to enter String (enter 1 for yes, 0 to exit)? : ");
				loopOuterProgram = sc.nextInt();
				loopInnerProgram = 1;
			}

		} catch (InputMismatchException ex) {
			System.out.println("Entered invalid choice: " + ex.getMessage());
		}

	}
}
