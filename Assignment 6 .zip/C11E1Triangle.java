/**
 * This program is used to calculate the area and perimeter of a triangle
 * It uses the methods getArea(),getPerimeter() and toString()
 */

import java.util.InputMismatchException;
/**
 *
 *This class extends super class Geometric Object
 *It uses super class method getArea() and getPerimeter() 
 */

public class C11E1Triangle extends GeometricObject {
    private double side1, side2, side3;
	String color;
	boolean filled;
	
	/**
	 * Default constructor
	 *we set default side values(side1,side2,side3)= 1 of triangle
	 * @throws InputMismatchException checks for invalid side values of the triangle
	 */
	C11E1Triangle() throws IllegalTriangleException{
		
		setSide1(1.0);
		setSide2(1.0);
		setSide3(1.0);
	}
	/**
	 * constructor set values for sides of triangle
	 * @param side1 first side of triangle
	 * @param side2 second side of triangle
	 * @param side3 third side of triangle
	 * @throws InputMismatchException checks for invalid side values of the triangle
	 */
	C11E1Triangle(double side1, double side2, double side3) throws IllegalTriangleException{
      setSide1(side1);
      setSide2(side2);
      setSide3(side3);
	}
	/**
	 * @param side1 value of first side of triangle
	 * @throws InputMismatchException handles exception check for invalid value of sides of triangle
	 */
	public void setSide1(double side1) throws InputMismatchException {
		if(isValid(side1)) {
			this.side1=side1;
		}else {
			throw new InputMismatchException("Invalid value (zero or negative value is not accepted for side of triangle)");
		}
	}
	/**
	 * @param side2 value of first side of triangle
	 * @throws InputMismatchException handles exception check for invalid value of sides of triangle
	 */
	public void setSide2(double side2) throws InputMismatchException {
		if(isValid(side2)) {
			this.side2=side2;
		}else {
			throw new InputMismatchException("Invalid value (zero or negative value is not accepted for side of triangle)");
		}
	}
	/**
	 * @param side3 value of first side of triangle
	 * @throws InputMismatchException handles exception check for invalid value of sides of triangle
	 */
	public void setSide3(double side3) throws InputMismatchException {
		if(isValid(side3)) {
			this.side3=side3;
		}else {
			throw new InputMismatchException("Invalid value (zero or negative value is not accepted for side of triangle)");
		}
	}
    /**
	* @param color string value of color of triangle
	*/
	public void setColor(String color) {
		this.color=color;
		
	}
	/**
	 * @param fill true if triangle is filled or else false
	 */
	public void setFill(boolean fill) {
		this.filled=fill;
	}
	/**
	 * @return triangle color
	 */
	public String getColor() {
		return color;
	}
	/**
	 * to determine if the triangle is filled with given color or not
	 * @return boolean value true if filled or else false
	 */
	public boolean getFilled() {
		return filled;
	}
	/**
	 *  @return value of first side of triangle
	 */
	public double getSide1() {
		return side1;
	}
	/**
	 * @return value of second side of triangle
	 */
	public double getSide2() {
		return side2;
	}
	/**
	 * @return value of third side of triangle
	 */
	public double getSide3() {
		return side3;
	}
	/**
	 * Determines if given side is valid side of triangle
	 * @param value of sides 
	 * @return true if valid, else false
	  */
	public boolean isValid(double value){
		if(value > 0 && value <= Double.MAX_VALUE) 
			return true;
		return false;
	}
	/**
	 * Determine if all sides of triangle are valid or not
	 * it checks sum of any two sides greater than the third side
	 * @return true if valid else false 
	 */
	public boolean isValidTriangle() {
		if(((side1+side2)>side3) && ((side2+side3)>side1) && ((side3+side1)>side2)) {
			return true;
		}else {
			return false;
		}
		}
	/**
	 * Overrides getArea() method of superclass
	 * @return  value of area of triangle
	 * @throws IllegalTriangleException 
	 */
	@Override
	public double getArea() throws IllegalTriangleException{
		if(isValidTriangle()) {
			double s =(side1 + side2 + side3)/2;
			return Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
		}else {
			throw new IllegalTriangleException();
		}
	}
	/**
	 * Overrides getPerimeter() method of superclass 
	 * @return value of perimeter of triangle
	 * @throws IllegalTriangleException 
	 */
	@Override
	public double getPerimeter() throws IllegalTriangleException{
		if(isValidTriangle()) {
			return (side1+ side2 +side3);
		}else {
			throw new IllegalTriangleException();
		}
	}
	/**
	*Overrides tostring() method of superclass
	*@return string message
	*/
	@Override
	public String toString() {
		return "Triangle : side1 = " + side1 + " side2 = " + side2 + " side3 = "+ side3;
	}
}
