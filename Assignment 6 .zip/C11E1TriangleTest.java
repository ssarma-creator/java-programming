// This is the test program for C11E1Triangle

import java.util.Scanner;
import java.util.InputMismatchException;

public class C11E1TriangleTest {
    public static void main(String[] args) throws IllegalTriangleException {
		boolean flag = false;
         Scanner input = new Scanner(System.in);
         int outerLoop = 1;

         //default constructor.
         // default value of 1 to all sides of triangle.
         //checks for exception cases
         try {

        	 C11E1Triangle t1 = new C11E1Triangle();
             System.out.println("The default sides of triangle : " + t1.toString());
             System.out.println("The default area of triangle = " + t1.getArea());
             System.out.println("The default perimeter of triangle = " + t1.getPerimeter());
             
         } catch (InputMismatchException | IllegalTriangleException ex) {
             System.out.println(ex.getMessage());
         }

         while (outerLoop == 1) {
             try {// handles InputMismatchException and IllegalTriangleException exceptions.

                 //Prompt user to enter sides of triangle.
                 System.out.println("\nEnter side1, side2 , side3 of triangle (separated by one space) : ");
                 double side1 = input.nextDouble();
                 double side2 = input.nextDouble();
                 double side3 = input.nextDouble();
                //Prompt user to enter triangle color and isfilled value.
                System.out.println("\nEnter color of triangle:");
                 String color = input.next();
                 System.out.print("\nIs the triangle filled? true/false:\n ");
                 String isFilledString = input.next();
                 boolean isFilled = (isFilledString.equals("true"));
              
                 C11E1Triangle t2 = new C11E1Triangle(side1, side2 , side3);
                 t2.setColor(color);
                 t2.setFill(isFilled);

                System.out.println(t2.toString());
                 System.out.println("Color of triangle = " + t2.getColor());
                 System.out.println("Is color filled in triangle = " + t2.getFilled());
                 System.out.println("Area of triangle = " + t2.getArea());
                 System.out.println("Perimeter of triangle = " + t2.getPerimeter());


             } catch (InputMismatchException | IllegalTriangleException ex) {
                 input.nextLine();
                 System.out.println(ex.getMessage());
             }

             System.out.println("\nProgram continue (enter 1 for yes, 0 to exit)? : ");
             outerLoop = input.nextInt();
         }

    }
}
 
