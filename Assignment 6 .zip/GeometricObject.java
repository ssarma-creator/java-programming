public class GeometricObject {
	/**
	 *This is a super class for rectangle and triangle
	 *This class provides generalized method getArea() and getPerimeter to its subclasses 
	 */	
	
	/**
	 * This method calculates area of geometric figure
     * @return double value of area.
     * @throws IllegalTriangleException provide exception handling
	 */
    public double getArea() throws IllegalTriangleException{
    	return 0.0;
	}
    /**
     * This method calculates perimeter of geometric figure.
     * @return double value of perimeter.
     * @throws IllegalTriangleException provide exception handling
     */
    public double getPerimeter() throws IllegalTriangleException{
    	return 0.0;
    }
    /**
     * This method used to display message.
     * @return string  message
     */
    public String toString() {
    	return "";
    }
}

