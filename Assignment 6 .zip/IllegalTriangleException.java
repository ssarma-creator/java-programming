
public class IllegalTriangleException extends Exception {

	IllegalTriangleException(){
		getMessage();
	}
	public String getMessage() {
	 return "Invalid input of the sides of the triangle, area and perimeter of the triangle cannot be calculated";
 }
}
