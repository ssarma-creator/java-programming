/**
 * This program that uses a bar chart to display the percentages of the overall grade represented by projects, quizzes, midterm 
 * exams, and the final exam
 */

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import javafx.scene.shape.Rectangle;
/**
 * This method overrides application start method
 * It creates bar chart using grid pane
 * @param primaryStage specifies the stage in which the image(bar chart)is displayed
 * @throws Exception exception occurs while loading images
 */
public class C14E12BarCharts extends Application {
    
	@Override
	
	public void start(Stage primaryStage) throws Exception{
		
		GridPane pane = new GridPane();
		pane.setPadding(new Insets(10,20,10,20));
		pane.setHgap(10);
		
		Label project = createLabel("Project--20%");
		Rectangle projectR1 = createRectangle(pane,Color.RED,.20);
		
		Label quiz = createLabel("Quiz--10%");
		Rectangle quizR2 = createRectangle(pane,Color.BLUE,.10);
		
		Label midterm = createLabel("Midterm--30%");
		Rectangle midtermR3 = createRectangle(pane,Color.GREEN,.30);
		
		Label finalExam = createLabel("Final--40%");
		Rectangle finalR4 = createRectangle(pane,Color.ORANGE,.40);
		//Adding the location of each rectangle
		pane.add(project, 3, 2, 1, 1);
		pane.add(projectR1, 3, 0, 1, 2);
		
		pane.add(quiz, 2, 1, 1, 1);
		pane.add(quizR2, 2, 0, 1, 1);
		
		pane.add(midterm, 1, 3, 1, 1);
		pane.add(midtermR3, 1, 0, 1, 3);
		
		pane.add(finalExam, 0, 4, 1, 1);
		pane.add(finalR4, 0, 0, 1, 4);
		
		pane.setRotate(180);
		
		Scene scene= new Scene(pane, 500, 500);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Bar chart");
		primaryStage.show();
	}
		/**
		 *method creating label
		 * @param text
		 * @return rotate 180 degree label
		 * @throws Exception
		 */
		private Label createLabel (String text) throws Exception{
			Label label = new Label(text);
			label.setRotate(180);
			return label;
		}
		
		/**
		 * Method used to create rectangle of the mentioned color and height
		 * @param pane gridpane where rectangle has to be placed
		 * @param color color of rectangle
		 * @param height value of rectangle height ratio
		 * @return rectangle of the mentioned height and color
		 * @throws Exception 
		 */
		private Rectangle createRectangle(GridPane pane, Color color, double height) throws Exception{
			Rectangle rec=new Rectangle();
			rec.setFill(color);
			rec.widthProperty().bind(pane.widthProperty().divide(4));
			rec.heightProperty().bind(pane.heightProperty().multiply(height));
			return rec;
		}
		/**
		 * This is the main function that contains application launch function
		 * @param args command line argument
		 */
		public static void main(String[] args) {
			try {
				Application.launch(args);
				
			}catch(Exception ex) {
				System.out.println("Exception found: " + ex.getMessage());
			}

		}

	}




