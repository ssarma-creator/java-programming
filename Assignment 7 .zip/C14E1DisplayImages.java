/**
 * This program displays four images in a grid pane
 */
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.image.ImageView;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;

/**
 * This method overrides application start method
 * @param primaryStage specifies the stage in which the image is displayed
 * @throws Exception exception occurs while loading images
 */


public class C14E1DisplayImages extends Application {
	
	@Override
	
	public void start(Stage primaryStage) throws Exception{
		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		pane.setPadding(new Insets(10,10,10,10));
		pane.setHgap(5.5);
		pane.setVgap(5.5);
		
		/**
		 * Taking image url and creating image
		 * 
		 */
		ImageView image1 = new ImageView(establishConnection("https://cdn.pixabay.com/photo/2017/03/14/21/00/american-flag-2144392_1280.png"));
		image1.fitHeightProperty().bind(pane.heightProperty().divide(4));
		image1.fitWidthProperty().bind(pane.widthProperty().divide(4));
		
		ImageView image2 = new ImageView(establishConnection("https://cdn.pixabay.com/photo/2015/11/06/13/29/union-jack-1027898_1280.jpg"));
		image2.fitHeightProperty().bind(pane.heightProperty().divide(4));
		image2.fitWidthProperty().bind(pane.widthProperty().divide(4));
		
		ImageView image3 = new ImageView(establishConnection("https://cdn.pixabay.com/photo/2012/04/10/23/27/canada-27003_1280.png"));
		image3.fitHeightProperty().bind(pane.heightProperty().divide(4));
		image3.fitWidthProperty().bind(pane.widthProperty().divide(4));
		
		ImageView image4 = new ImageView(establishConnection("https://cdn.pixabay.com/photo/2017/05/12/09/07/china-2306580_1280.png"));
		image4.fitHeightProperty().bind(pane.heightProperty().divide(4));
		image4.fitWidthProperty().bind(pane.widthProperty().divide(4));
		
		/**
		 * Adding the location of each image
		 */
		pane.add(image2, 0, 0, 1, 1);
		pane.add(image3, 1, 0, 1, 1);
		pane.add(image1, 1, 1, 1, 1);
		pane.add(image4, 0, 1, 1, 1);
		
		Scene scene = new Scene(pane, 200, 200);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Display image");
		primaryStage.show();
		
	}
	/** This method creates URL connection for loading image 
	 * @param url
	 * @return Image after creating and establishing secure connection
	 * @throws IOException
	 */
	
	private Image establishConnection(String url) throws IOException {
		String imageUrl = url;
		URLConnection connection = new URL(imageUrl).openConnection();
		connection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
		Image image = new Image(connection.getInputStream());
		return image;
	}
	/**
	 * This is the main function that contains application launch function
	 * @param args command line argument
	 */

	public static void main(String[] args) {
		try {
			Application.launch(args);
			
		}catch(Exception ex) {
			System.out.println("Exception found: " + ex.getMessage());
		}

	}

}
